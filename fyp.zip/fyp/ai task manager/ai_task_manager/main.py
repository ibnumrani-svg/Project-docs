from flask import Flask, render_template, request, redirect, url_for, session, flash,jsonify
import firebase_admin
from firebase_admin import credentials, db
import yagmail
import random
import os
from pathlib import Path
from datetime import datetime, date
from apscheduler.schedulers.background import BackgroundScheduler
import pytz
import atexit
import google.generativeai as genai

app = Flask(__name__)
app.secret_key = 'your_secret_key'

# --- Firebase Initialization (ONLY Realtime Database) ---
cred = credentials.Certificate(r"C:\Users\pc\Desktop\fyp\ai task manager\ai_task_manager\student-task-manager-c6eda-firebase-adminsdk-fbsvc-b5e119afd6.json")  # Replace with your service account JSON
firebase_admin.initialize_app(cred, {
    'databaseURL': 'https://student-task-manager-c6eda-default-rtdb.firebaseio.com/'  # Replace with your Firebase Realtime DB URL
})

# --- Email Setup (yagmail) ---
yag = yagmail.SMTP("taimoorrajpoot596@gmail.com", "ztdfazpsyeqypdeu")  # Replace with your Gmail + App Password


# ------------------ ROUTES ------------------

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        data = request.form
        image = request.files['image']
        email = data['email']
        email_key = email.replace('.', '-')

        # Save image to static/images/
        image_path = os.path.join('static/images', image.filename)
        image.save(image_path)

        # Prepare user data
        user_data = {
            'name': data.get('name'),
            'father_name': data.get('father_name'),
            'email': email,
            'password': data.get('password'),
            'address': data.get('address'),
            'contact': data.get('contact'),
            'image': image_path,
            'status': 'true'
        }

        try:
            # Store in Firebase Realtime Database
            db.reference(f'users/{email_key}').set(user_data)
            flash("Signup successful! Please login.")
            return redirect(url_for('login'))
        except Exception as e:
            flash(f"Error: {str(e)}")
            return render_template("signup.html")

    return render_template("signup.html")

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        email_key = email.replace('.', '-')

        try:
            user = db.reference(f'users/{email_key}').get()
            if user:
                if user['password'] == password:
                    if user['status'] == 'true':
                        session['user'] = user
                        return redirect(url_for('student_dashboard'))
                    else:
                        flash("Your account is not approved yet.")
                else:
                    flash("Incorrect password.")
            else:
                flash("User not found.")
        except Exception as e:
            flash(f"Login failed: {str(e)}")

    return render_template("login.html")

@app.route('/forgot_password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form['email']
        otp = str(random.randint(100000, 999999))
        session['reset_email'] = email
        session['otp'] = otp

        yag.send(email, "Your OTP Code", f"Your OTP is: {otp}")
        return redirect(url_for('reset_password'))

    return render_template("forgot_password.html")


@app.route('/reset_password', methods=['GET', 'POST'])
def reset_password():
    if request.method == 'POST':
        email = request.form['email']
        otp = request.form['otp']
        new_password = request.form['new_password']
        confirm_password = request.form['confirm_password']

        if otp == session.get('otp') and new_password == confirm_password:
            key = email.replace('.', '-')
            db.reference(f'users/{key}/password').set(new_password)
            flash("Password reset successfully.")
            return redirect(url_for('login'))
        else:
            flash("OTP invalid or passwords do not match.")

    return render_template("reset_password.html")

@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        if email == 'admin@gmail.com' and password == '123456789':
            session['admin'] = True
            return redirect(url_for('admin_dashboard'))
        else:
            flash("Admin login failed.")
    return render_template("admin_login.html")


@app.route('/admin_dashboard')
def admin_dashboard():
    if not session.get('admin'):
        return redirect(url_for('admin_login'))

    users_raw = db.reference('users').get() or {}
    users = {}

    for key, user in users_raw.items():
        if 'image' in user and user['image']:
            # Safely get filename regardless of OS (Windows/Linux)
            filename = Path(user['image']).name
            user['image_url'] = url_for('static', filename=f'images/{filename}')
        else:
            user['image_url'] = url_for('static', filename='images/default.png')
        users[key] = user

    return render_template('admin_dashboard.html', users=users)

@app.route('/approve_user/<email>')
def approve_user(email):
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    key = email.replace('.', '-')
    db.reference(f'users/{key}/status').set('true')
    user = db.reference(f'users/{key}').get()
    yag.send(to=user['email'], subject='Account Approved', contents='Your account has been approved.')
    return redirect(url_for('admin_dashboard'))

@app.route('/reject_user/<email>')
def reject_user(email):
    if not session.get('admin'):
        return redirect(url_for('admin_login'))
    key = email.replace('.', '-')
    db.reference(f'users/{key}/status').set('false')
    user = db.reference(f'users/{key}').get()
    yag.send(to=user['email'], subject='Account Rejected', contents='Your account has been rejected.')
    return redirect(url_for('admin_dashboard'))






def normalize_static_path(p: str) -> str:
    """
    Accepts:
      - static/images\\abc.jpg
      - static/images/abc.jpg
      - images\\abc.jpg
      - images/abc.jpg
    Returns:
      - images/abc.jpg
    """
    if not p:
        return ""
    p = p.strip().replace("\\", "/")
    if "/static/" in p:
        p = p.split("/static/", 1)[1]
    if p.startswith("static/"):
        p = p[len("static/"):]
    return p


@app.route('/student_dashboard')
def student_dashboard():
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')

    task_data = db.reference(f'tasks/{email_key}').get() or {}
    goal_data = db.reference(f'goals/{email_key}').get() or {}

    today = datetime.now().date()

    # Initialize task categories
    pending_tasks = []
    completed_tasks = []
    incomplete_tasks = []

    # Initialize goal categories
    active_goals = []
    completed_goals = []
    incomplete_goals = []

    # Categorize tasks
    for task_id, task in task_data.items():
        task['id'] = task_id
        task_date = datetime.strptime(task['date'], '%Y-%m-%d').date()

        if task.get('status') == 'completed':
            completed_tasks.append(task)
        elif task.get('status') == 'not_done' or task_date < today:
            incomplete_tasks.append(task)
        else:
            pending_tasks.append(task)

    # Categorize goals
    for goal_id, goal in goal_data.items():
        goal['id'] = goal_id
        goal_date = datetime.strptime(goal['goal_date'], '%Y-%m-%d').date()

        if goal.get('status') == 'completed':
            completed_goals.append(goal)
        elif goal.get('status') == 'not_done' or goal_date < today:
            incomplete_goals.append(goal)
        else:
            active_goals.append(goal)

    # Prepare counts dictionary
    counts = {
        'active_tasks': len(pending_tasks),
        'completed_tasks': len(completed_tasks),
        'incomplete_tasks': len(incomplete_tasks),
        'active_goals': len(active_goals),
        'completed_goals': len(completed_goals),
        'incomplete_goals': len(incomplete_goals),
    }

    # ✅✅ PROFILE IMAGE FIX (Added inside same router)
    raw_image = session['user'].get('image', '') or ''
    clean_image = normalize_static_path(raw_image)
    if not clean_image:
        clean_image = 'img/default-avatar.png'  # put this in static/img/
    profile_image_url = url_for('static', filename=clean_image)

    # ✅✅ NOTIFICATIONS FETCH (Unread, Today's)
    notif_data = db.reference(f'notifications/{email_key}').get() or {}
    notifications = []
    today_str = str(date.today())

    for nid, n in notif_data.items():
        if isinstance(n, dict) and (n.get("read") is False):
            if n.get("date") == today_str:     # only today popups
                n["id"] = nid
                notifications.append(n)

    notifications.sort(key=lambda x: x.get("created_at", ""), reverse=True)

    return render_template(
        'student_dashboard.html',
        user=session['user'],
        counts=counts,                         # ✅ Now passing this
        profile_image_url=profile_image_url,   # ✅ Added
        notifications=notifications             # ✅ Added
    )


# ✅ Dismiss notification (mark read)
@app.route("/dismiss_notification/<nid>", methods=["POST"])
def dismiss_notification(nid):
    if 'user' not in session:
        return jsonify({"ok": False}), 401

    email_key = session['user']['email'].replace('.', '-')
    db.reference(f'notifications/{email_key}/{nid}/read').set(True)
    return jsonify({"ok": True})

#----------------------add task router-------------------------------------------------------------
@app.route('/add_task', methods=['GET', 'POST'])
def add_task():
    if 'user' not in session:
        return redirect(url_for('login'))

    if request.method == 'POST':
        data = request.form
        email_key = session['user']['email'].replace('.', '-')
        task_id = str(random.randint(100000, 999999))

        task_data = {
            'task_name': data['task_name'],
            'date': data['date'],
            'day': data['day'],
            'start_time': data['start_time'],
            'end_time': data['end_time'],
            'priority': data['priority'],
            'task_details': data['task_details'],
            'status': 'pending',
            'id': task_id
        }

        db.reference(f'tasks/{email_key}/{task_id}').set(task_data)
        flash('✅ Task added successfully!', 'success')
        return redirect(url_for('view_tasks'))

    return render_template('add_task.html')


@app.route('/add_goal', methods=['POST'])
def add_goal():
    if 'user' not in session:
        return redirect(url_for('login'))

    data = request.form
    email_key = session['user']['email'].replace('.', '-')
    goal_id = str(random.randint(100000, 999999))

    goal_data = {
        'goal_name': data['goal_name'],
        'goal_date': data['goal_date'],
        'goal_time': data['goal_time'],
        'goal_description': data.get('goal_description', ''),
        'status': 'active',
        'id': goal_id
    }

    db.reference(f'goals/{email_key}/{goal_id}').set(goal_data)
    flash('🎯 Goal added successfully!', 'success')
    return redirect(url_for('reminder_set'))  # ✅ changed from view_tasks to reminder_set

#----------------------------------------------------------------------------------
@app.route('/view_tasks')
def view_tasks():
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')

    task_data = db.reference(f'tasks/{email_key}').get() or {}
    goal_data = db.reference(f'goals/{email_key}').get() or {}

    pending_tasks = []
    completed_tasks = []
    incomplete_tasks = []

    active_goals = []
    completed_goals = []
    incomplete_goals = []

    today = datetime.now().date()

    for task_id, task in task_data.items():
        task['id'] = task_id
        task_date = datetime.strptime(task['date'], '%Y-%m-%d').date()
        if task.get('status') == 'completed':
            completed_tasks.append(task)
        elif task.get('status') == 'not_done' or task_date < today:
            incomplete_tasks.append(task)
        else:
            pending_tasks.append(task)

    for goal_id, goal in goal_data.items():
        goal['id'] = goal_id
        goal_date = datetime.strptime(goal['goal_date'], '%Y-%m-%d').date()
        if goal.get('status') == 'completed':
            completed_goals.append(goal)
        elif goal.get('status') == 'not_done' or goal_date < today:
            incomplete_goals.append(goal)
        else:
            active_goals.append(goal)

    counts = {
        'active_tasks': len(pending_tasks),
        'completed_tasks': len(completed_tasks),
        'incomplete_tasks': len(incomplete_tasks),
        'active_goals': len(active_goals),
        'completed_goals': len(completed_goals),
        'incomplete_goals': len(incomplete_goals),
    }

    return render_template(
        "view_tasks.html",
        pending_tasks=pending_tasks,
        completed_tasks=completed_tasks,
        incomplete_tasks=incomplete_tasks,
        active_goals=active_goals,
        completed_goals=completed_goals,
        incomplete_goals=incomplete_goals,
        counts=counts
    )


@app.route('/update_task_status/<task_id>/<status>', methods=['POST'])
def update_task_status(task_id, status):
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')
    db.reference(f'tasks/{email_key}/{task_id}/status').set('completed' if status == 'done' else 'not_done')
    return redirect(url_for('view_tasks'))


@app.route('/update_goal_status/<goal_id>/<status>', methods=['POST'])
def update_goal_status(goal_id, status):
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')
    db.reference(f'goals/{email_key}/{goal_id}/status').set('completed' if status == 'done' else 'not_done')
    return redirect(url_for('view_tasks'))


@app.route('/finalize_day/<date_day>', methods=['POST'])
def finalize_day(date_day):
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')
    task_data = db.reference(f'tasks/{email_key}').get() or {}

    all_completed = True
    for task_id, task in task_data.items():
        if f"{task['date']}_{task['day']}" == date_day:
            if task['status'] != 'completed':
                all_completed = False
                break

    # Final update
    for task_id, task in task_data.items():
        if f"{task['date']}_{task['day']}" == date_day:
            db.reference(f'tasks/{email_key}/{task_id}/status').set(
                'completed' if all_completed else 'not_done'
            )

    return redirect(url_for('view_tasks'))
#----------------------------------------------------------------------------------------------------------------------------------
# ---------- Reminder Routes ----------


@app.route('/reminder_set', methods=['GET', 'POST'])
def reminder_set():
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')
    goals_ref = db.reference(f'goals/{email_key}')
    goals = goals_ref.get() or {}

    goal_list = []
    for goal_id, goal_data in goals.items():
        goal_data['id'] = goal_id
        goal_list.append(goal_data)

    return render_template('reminder_set.html', goals=goal_list)


@app.route('/set_reminder', methods=['POST'])
def set_reminder():
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')
    goal_id = request.form['goal_id']
    reminder_time = request.form['reminder_time']

    # Validate time format
    try:
        datetime.strptime(reminder_time, "%H:%M")
    except ValueError:
        flash('❌ Invalid time format. Please use HH:MM', 'error')
        return redirect(url_for('reminder_set'))

    # Set reminder with all necessary fields
    goal_ref = db.reference(f'goals/{email_key}/{goal_id}')
    goal_ref.update({
        'reminder_time': reminder_time,
        'status': 'active',
        'last_sent_date': ''  # Reset to empty
    })

    print(f"✅ Reminder set for goal {goal_id} at {reminder_time}")
    flash('⏰ Reminder set successfully! Daily email milegi.', 'success')
    return redirect(url_for('reminder_set'))


@app.route('/remove_reminder', methods=['POST'])
def remove_reminder():
    if 'user' not in session:
        return redirect(url_for('login'))

    email_key = session['user']['email'].replace('.', '-')
    goal_id = request.form['goal_id']

    goal_ref = db.reference(f'goals/{email_key}/{goal_id}')
    goal_ref.update({
        'reminder_time': None,
        'last_sent_date': None,
        'status': 'paused'
    })

    print(f"🚫 Reminder removed for goal {goal_id}")
    flash('🚫 Reminder stopped successfully!', 'success')
    return redirect(url_for('reminder_set'))


# ---------- Yagmail Configuration ----------
try:
    yag = yagmail.SMTP("taimoorrajpoot596@gmail.com", "ztdfazpsyeqypdeu")
    print("✅ Yagmail configured successfully")
except Exception as e:
    print(f"❌ Yagmail configuration failed: {e}")
    yag = None

def send_daily_reminders():
    """
    Har minute check karta hai aur specified time par reminders bhejta hai
    + Email send hone par dashboard popup ke liye notification save karta hai
    """
    try:
        # Check if yagmail is configured
        if yag is None:
            print("⚠️ Yagmail not configured. Skipping reminder check.")
            return

        all_users = db.reference('goals').get()

        if not all_users:
            print("ℹ️ No users found in database")
            return

        # Pakistan timezone
        pk_tz = pytz.timezone("Asia/Karachi")
        now = datetime.now(pk_tz)
        current_time = now.strftime("%H:%M")
        current_time_with_seconds = now.strftime("%H:%M:%S")
        today = str(date.today())

        print(f"\n{'=' * 60}")
        print(f"🕐 Reminder Check: {current_time_with_seconds} on {today}")
        print(f"{'=' * 60}")

        reminder_count = 0

        for email_key, goals in all_users.items():
            if not isinstance(goals, dict):
                continue

            for goal_id, goal_data in goals.items():
                if not isinstance(goal_data, dict):
                    continue

                goal_name = goal_data.get('goal_name', 'Unnamed Goal')
                goal_date_str = goal_data.get('goal_date')
                reminder_time = goal_data.get('reminder_time')
                goal_status = goal_data.get('status', 'active')
                last_sent = goal_data.get('last_sent_date', '')

                # Debug info
                print(f"\n📋 Checking Goal: {goal_name}")
                print(f"   ├─ Goal ID: {goal_id}")
                print(f"   ├─ Status: {goal_status}")
                print(f"   ├─ Reminder Time: {reminder_time}")
                print(f"   ├─ Goal Date: {goal_date_str}")
                print(f"   ├─ Last Sent: {last_sent}")
                print(f"   └─ Current Time: {current_time}")

                # Skip conditions
                if not reminder_time:
                    print(f"   ⏭️ Skipped: No reminder time set")
                    continue

                if not goal_date_str:
                    print(f"   ⏭️ Skipped: No goal date set")
                    continue

                if goal_status != 'active':
                    print(f"   ⏭️ Skipped: Goal is {goal_status}")
                    continue

                # Parse goal date
                try:
                    goal_date = datetime.strptime(goal_date_str, "%Y-%m-%d").date()
                except ValueError:
                    print(f"   ⚠️ Invalid date format: {goal_date_str}")
                    continue

                # Check if goal expired
                if goal_date < date.today():
                    print(f"   ⏭️ Skipped: Goal expired on {goal_date}")
                    continue

                # Check if already sent today
                if last_sent == today:
                    print(f"   ⏭️ Skipped: Already sent today")
                    continue

                print(f"   🔍 Time comparison: '{current_time}' == '{reminder_time}' ?")

                if current_time == reminder_time:
                    print(f"   ✅ TIME MATCHED! Sending email...")

                    user_email = email_key.replace('-', '.')
                    days_remaining = (goal_date - date.today()).days

                    subject = f"🎯 Daily Goal Reminder: {goal_name}"
                    message = f"""
                    <html>
                    <body style='font-family: Arial, sans-serif; padding: 20px;'>
                        <div style='max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); padding: 30px; border-radius: 15px;'>
                            <h2 style='color: white; text-align: center;'>🎯 Goal Reminder</h2>
                        </div>
                        <div style='max-width: 600px; margin: 20px auto; background: white; padding: 30px; border-radius: 15px; box-shadow: 0 4px 6px rgba(0,0,0,0.1);'>
                            <h3 style='color: #333;'>Hi there 👋</h3>
                            <p style='font-size: 16px; color: #555;'>Ye aapka daily reminder hai apne goal ke liye:</p>

                            <div style='background: linear-gradient(135deg, #f5f7fa 0%, #c3cfe2 100%); padding: 20px; border-radius: 10px; margin: 20px 0;'>
                                <h4 style='margin: 0; color: #667eea; font-size: 20px;'>{goal_name}</h4>
                                <p style='margin: 10px 0; color: #555;'><strong>Target Date:</strong> {goal_date.strftime('%d %B %Y')}</p>
                                <p style='margin: 10px 0; color: #555;'><strong>Days Remaining:</strong> <span style='color: #e74c3c; font-size: 24px; font-weight: bold;'>{days_remaining}</span> days</p>
                            </div>

                            <p style='font-size: 16px; color: #555;'>Stay consistent aur apne goal par focused rahein! 💪</p>
                            <p style='font-size: 18px; color: #667eea; font-weight: bold; text-align: center; margin-top: 20px;'>Aap kar sakte hain! 🚀</p>
                        </div>
                        <div style='max-width: 600px; margin: 0 auto; text-align: center; padding: 20px;'>
                            <p style='color: #999; font-size: 12px;'>AI Task Manager - Automated Reminder System</p>
                            <p style='color: #999; font-size: 11px;'>Reminders band karne ke liye reminder settings mein jaakar "Stop Reminder" par click karein.</p>
                        </div>
                    </body>
                    </html>
                    """

                    try:
                        yag.send(
                            to=user_email,
                            subject=subject,
                            contents=message
                        )
                        print(f"   ✉️ Email sent successfully to {user_email}")

                        # ✅ Update last sent date
                        db.reference(f'goals/{email_key}/{goal_id}/last_sent_date').set(today)
                        print(f"   💾 Updated last_sent_date to {today}")

                        # ✅✅ NEW: Dashboard popup notification save
                        notif = {
                            "type": "reminder",
                            "title": "Goal Reminder Sent ✅",
                            "message": f"Reminder email sent for goal: {goal_name}",
                            "goal_id": goal_id,
                            "goal_name": goal_name,
                            "target_date": goal_date_str,
                            "reminder_time": reminder_time,
                            "date": today,
                            "created_at": now.isoformat(),
                            "read": False
                        }
                        db.reference(f'notifications/{email_key}').push(notif)
                        print("   🔔 Notification saved for dashboard")

                        reminder_count += 1

                    except Exception as e:
                        print(f"   ❌ Email sending failed: {str(e)}")
                        if "authentication" in str(e).lower():
                            print("   🔐 Authentication issue - check email credentials")
                        elif "connection" in str(e).lower():
                            print("   🌐 Connection issue - check internet")
                else:
                    print(f"   ⏭️ Time not matched yet")

        print(f"\n{'=' * 60}")
        print(f"📊 Summary: {reminder_count} reminder(s) sent")
        print(f"{'=' * 60}\n")

    except Exception as e:
        print(f"\n❌ Global Reminder Error: {str(e)}")
        import traceback
        traceback.print_exc()


# ---------- Test Email Function ----------
def test_email_system():
    """Test email system separately"""
    print("\n🧪 Testing Email System...")

    if yag is None:
        print("❌ Yagmail not configured properly")
        return False

    try:
        test_subject = "🎯 Test Email - AI Task Manager"
        test_message = """
        <html>
        <body>
            <h2>Test Email Successful! ✅</h2>
            <p>Your email system is working properly.</p>
        </body>
        </html>
        """

        yag.send(
            to="taimoorrajpoot596@gmail.com",
            subject=test_subject,
            contents=test_message
        )
        print("✅ Test email sent successfully!")
        return True

    except Exception as e:
        print(f"❌ Test email failed: {e}")
        return False


# ---------- Scheduler Setup ----------
scheduler = BackgroundScheduler(timezone="Asia/Karachi")

# Run every minute
scheduler.add_job(
    func=send_daily_reminders,
    trigger='interval',
    minutes=1,
    id='reminder_checker',
    replace_existing=True
)

# Start scheduler
try:
    scheduler.start()
    print("\n" + "=" * 60)
    print("✅ Reminder Scheduler Started Successfully!")
    print("🕐 Checking for reminders every minute...")
    print("=" * 60 + "\n")

    # Run test immediately
    test_email_system()

except Exception as e:
    print(f"\n❌ Scheduler failed to start: {e}\n")

# Cleanup on shutdown
atexit.register(lambda: scheduler.shutdown())

# ---------- Testing Route (Optional) ----------
@app.route('/test_reminder')
def test_reminder():
    """Manual trigger to test reminder system"""
    if 'user' not in session:
        return "Please login first"

    send_daily_reminders()
    return "✅ Reminder check triggered! Check console for logs."






#--------------------------------------------------------------------------------------------------
# --------------------- GEMINI CONFIG ---------------------
GOOGLE_API_KEY = "AIzaSyBL5A2qusSA5Wn5xwPW6PJVnJH2126fMrc"
genai.configure(api_key=GOOGLE_API_KEY)
model = genai.GenerativeModel("gemini-2.5-flash")


# -------------------- AI Insight Route --------------------
@app.route('/ai_insight')
def ai_insight():
    if 'user' not in session:
        return redirect(url_for('login'))

    return render_template("ai_insight.html")


@app.route('/ai_insight_chat', methods=['POST'])
def ai_insight_chat():
    if 'user' not in session:
        return jsonify({"reply": "⚠ Please login first.", "error": True})

    try:
        data = request.get_json()
        user_message = data.get("message", "").strip()

        if not user_message:
            return jsonify({"reply": "⚠ Please type a message.", "error": True})

        email_key = session['user']['email'].replace('.', '-')
        today = datetime.now()
        today_date = today.date()
        today_str = today.strftime('%Y-%m-%d')
        today_day = today.strftime('%A')  # Day name like 'Thursday'
        current_time = today.strftime('%I:%M %p')

        # Fetch ALL today's tasks from database
        task_data = db.reference(f'tasks/{email_key}').get() or {}

        today_tasks = []
        high_priority_tasks = []
        medium_priority_tasks = []
        low_priority_tasks = []

        for task_id, task in task_data.items():
            task_date = datetime.strptime(task['date'], '%Y-%m-%d').date()

            # Only get today's tasks
            if task_date == today_date:
                task_info = {
                    'id': task_id,
                    'task': task.get('task', 'N/A'),
                    'priority': task.get('priority', 'medium').lower(),
                    'status': task.get('status', 'pending'),
                    'category': task.get('category', 'general'),
                    'time': task.get('time', 'Not specified'),
                    'day': task.get('day', today_day)
                }

                today_tasks.append(task_info)

                # Separate by priority
                if task_info['priority'] == 'high':
                    high_priority_tasks.append(task_info)
                elif task_info['priority'] == 'medium':
                    medium_priority_tasks.append(task_info)
                else:
                    low_priority_tasks.append(task_info)

        # Check if user is asking for task suggestions
        is_task_request = any(keyword in user_message.lower() for keyword in
                              ['task', 'schedule', 'time table', 'timetable', 'suggest', 'plan',
                               'organize', 'today', 'what should', 'help', 'kya', 'karna'])

        # Build detailed context for AI
        if today_tasks:
            task_context = f"""
📅 TODAY'S INFORMATION:
- Date: {today_str}
- Day: {today_day}
- Current Time: {current_time}
- Total Tasks: {len(today_tasks)}
- High Priority: {len(high_priority_tasks)}
- Medium Priority: {len(medium_priority_tasks)}
- Low Priority: {len(low_priority_tasks)}

📋 COMPLETE TASK LIST FOR TODAY:
"""
            # Add High Priority Tasks
            if high_priority_tasks:
                task_context += "\n🔴 HIGH PRIORITY TASKS (DO FIRST!):\n"
                for i, task in enumerate(high_priority_tasks, 1):
                    status_emoji = "✅" if task['status'] == 'completed' else "⏳"
                    task_context += f"   {i}. {status_emoji} {task['task']}\n"
                    task_context += f"      • Category: {task['category']}\n"
                    task_context += f"      • Time: {task['time']}\n"
                    task_context += f"      • Status: {task['status']}\n\n"

            # Add Medium Priority Tasks
            if medium_priority_tasks:
                task_context += "\n🟡 MEDIUM PRIORITY TASKS:\n"
                for i, task in enumerate(medium_priority_tasks, 1):
                    status_emoji = "✅" if task['status'] == 'completed' else "⏳"
                    task_context += f"   {i}. {status_emoji} {task['task']}\n"
                    task_context += f"      • Category: {task['category']}\n"
                    task_context += f"      • Time: {task['time']}\n"
                    task_context += f"      • Status: {task['status']}\n\n"

            # Add Low Priority Tasks
            if low_priority_tasks:
                task_context += "\n🟢 LOW PRIORITY TASKS (Optional/If time permits):\n"
                for i, task in enumerate(low_priority_tasks, 1):
                    status_emoji = "✅" if task['status'] == 'completed' else "⏳"
                    task_context += f"   {i}. {status_emoji} {task['task']}\n"
                    task_context += f"      • Category: {task['category']}\n"
                    task_context += f"      • Time: {task['time']}\n"
                    task_context += f"      • Status: {task['status']}\n\n"

            if is_task_request:
                enhanced_prompt = f"""
You are an expert AI Task Manager and Productivity Coach. 

{task_context}

User's Question: {user_message}

YOUR MAIN JOB:
Create a DETAILED, PRACTICAL TIME TABLE for today based on the tasks above.

INSTRUCTIONS FOR TIME TABLE:
1. ⚡ START with HIGH PRIORITY tasks FIRST (these are most important!)
2. 📊 Consider the current time ({current_time}) - suggest what to do NOW
3. ⏰ Assign SPECIFIC time slots for each task (e.g., "9:00 AM - 10:30 AM")
4. 🎯 Group similar category tasks together when possible
5. ⏸️ Include 10-15 minute breaks between tasks
6. 💡 Explain WHY you're suggesting this order
7. ✨ Give productivity tips for each task
8. 🚀 Motivate the user to start!

FORMAT YOUR RESPONSE LIKE THIS:

🌟 **Good {today_day}! Here's your optimized schedule:**

⏰ **IMMEDIATE ACTION (Right Now - {current_time}):**
[Suggest what to start immediately]

📅 **YOUR COMPLETE TIME TABLE FOR TODAY:**

**Morning/Afternoon/Evening Block:**
🔴 [Time Slot] - [High Priority Task Name]
   💡 Why first: [Reason]
   ✨ Tip: [Quick productivity tip]

[Continue for all tasks...]

⏸️ **Recommended Breaks:**
- [Break times and suggestions]

🎯 **KEY PRIORITIES TODAY:**
1. [Most important thing]
2. [Second important]
3. [Third important]

💪 **MOTIVATION:**
[Encouraging message to start the day]

🔥 **Pro Tips:**
- [Helpful advice for completing tasks efficiently]

Remember: Be specific with times, encouraging, and practical!
"""
            else:
                # For general questions but show tasks summary
                enhanced_prompt = f"""
You are a friendly AI Assistant for productivity and motivation.

{task_context}

User's Message: {user_message}

Respond warmly to their question. You can mention their tasks if relevant, but focus on answering what they asked.
Use emojis and be encouraging!
"""

        else:
            # No tasks for today
            enhanced_prompt = f"""
You are a friendly AI Assistant for productivity and motivation.

ℹ️ The user has NO TASKS scheduled for today ({today_str} - {today_day}).

User's Message: {user_message}

Respond to:
- Greetings (Hi, Hello, etc.)
- Motivational quote requests  
- Study tips and productivity advice
- General conversation

If they ask about tasks, politely inform them they don't have any tasks for today and suggest they:
1. Add some tasks for today
2. Plan for tomorrow
3. Take this as a free day to rest or do spontaneous activities

Be warm, supportive, and helpful. Use emojis to make responses engaging.
"""

        # Generate AI response using Gemini
        response = model.generate_content(enhanced_prompt)
        bot_reply = response.text.strip()

        return jsonify({
            "reply": bot_reply,
            "tasks_today": len(today_tasks),
            "has_tasks": len(today_tasks) > 0,
            "high_priority": len(high_priority_tasks),
            "medium_priority": len(medium_priority_tasks),
            "low_priority": len(low_priority_tasks),
            "current_time": current_time,
            "today_day": today_day
        })

    except Exception as e:
        logger.error(f"AI Insight error: {e}")
        return jsonify({
            "reply": "⚠ Sorry, I'm having trouble right now. Please try again in a moment.",
            "error": True
        })


@app.route('/get_today_tasks_summary')
def get_today_tasks_summary():
    """API endpoint to get today's tasks summary"""
    if 'user' not in session:
        return jsonify({"error": "Not logged in"}), 401

    try:
        email_key = session['user']['email'].replace('.', '-')
        today = datetime.now().date()

        task_data = db.reference(f'tasks/{email_key}').get() or {}

        today_tasks = {
            'high': [],
            'medium': [],
            'low': [],
            'total': 0,
            'completed': 0,
            'pending': 0
        }

        for task_id, task in task_data.items():
            task_date = datetime.strptime(task['date'], '%Y-%m-%d').date()
            if task_date == today:
                priority = task.get('priority', 'medium').lower()
                task_info = {
                    'id': task_id,
                    'task': task.get('task', 'N/A'),
                    'status': task.get('status', 'pending'),
                    'time': task.get('time', 'N/A'),
                    'category': task.get('category', 'general')
                }

                if priority in today_tasks:
                    today_tasks[priority].append(task_info)

                today_tasks['total'] += 1
                if task.get('status') == 'completed':
                    today_tasks['completed'] += 1
                else:
                    today_tasks['pending'] += 1

        return jsonify(today_tasks)

    except Exception as e:
        logger.error(f"Error fetching tasks summary: {e}")
        return jsonify({"error": str(e)}), 500


@app.route('/get_ai_suggestion')
def get_ai_suggestion():
    """Auto-generate time table suggestion on page load"""
    if 'user' not in session:
        return jsonify({"error": "Not logged in"}), 401

    try:
        email_key = session['user']['email'].replace('.', '-')
        today = datetime.now()
        today_date = today.date()
        today_str = today.strftime('%Y-%m-%d')
        today_day = today.strftime('%A')
        current_time = today.strftime('%I:%M %p')

        task_data = db.reference(f'tasks/{email_key}').get() or {}

        today_tasks = []
        for task_id, task in task_data.items():
            task_date = datetime.strptime(task['date'], '%Y-%m-%d').date()
            if task_date == today_date:
                today_tasks.append({
                    'id': task_id,
                    'task': task.get('task', 'N/A'),
                    'priority': task.get('priority', 'medium'),
                    'status': task.get('status', 'pending'),
                    'category': task.get('category', 'general'),
                    'time': task.get('time', 'Not specified')
                })

        if not today_tasks:
            return jsonify({
                "suggestion": "🌟 You have no tasks for today! It's a great day to relax or plan ahead.",
                "has_tasks": False,
                "time_table": []
            })

        # Sort by priority
        priority_order = {'high': 0, 'medium': 1, 'low': 2}
        today_tasks.sort(key=lambda x: priority_order.get(x['priority'].lower(), 1))

        # Generate smart time table suggestion
        time_table_suggestion = generate_smart_time_table(today_tasks, current_time)

        # Create comprehensive summary
        high_count = len([t for t in today_tasks if t['priority'].lower() == 'high'])
        medium_count = len([t for t in today_tasks if t['priority'].lower() == 'medium'])
        low_count = len([t for t in today_tasks if t['priority'].lower() == 'low'])
        completed_count = len([t for t in today_tasks if t.get('status') == 'completed'])

        suggestion = f"📋 **Today's Plan ({today_day})**\n\n"
        suggestion += f"You have {len(today_tasks)} tasks today:\n"
        suggestion += f"• 🔥 {high_count} High Priority\n"
        suggestion += f"• ⚡ {medium_count} Medium Priority\n"
        suggestion += f"• 💤 {low_count} Low Priority\n"
        suggestion += f"• ✅ {completed_count} Completed\n\n"

        if high_count > 0:
            suggestion += "**Recommendation:** Start with high priority tasks first! Focus on completing them before moving to others. 🔥"
        elif medium_count > 0:
            suggestion += "**Recommendation:** You have moderate tasks today. Complete medium priority tasks efficiently. ⚡"
        else:
            suggestion += "**Recommendation:** You have light tasks today. Perfect day for planning and organization. 📅"

        return jsonify({
            "suggestion": suggestion,
            "has_tasks": True,
            "total_tasks": len(today_tasks),
            "high_priority": high_count,
            "medium_priority": medium_count,
            "low_priority": low_count,
            "completed_tasks": completed_count,
            "time_table": time_table_suggestion,
            "current_time": current_time
        })

    except Exception as e:
        logger.error(f"Error generating suggestion: {e}")
        return jsonify({"error": str(e)}), 500


def generate_smart_time_table(tasks, current_time):
    """Generate smart time table based on priority and time"""
    time_slots = [
        "Morning (8AM-12PM)", "Afternoon (12PM-4PM)",
        "Evening (4PM-8PM)", "Night (8PM-12AM)"
    ]

    time_table = []

    # High priority tasks - Morning and Afternoon
    high_tasks = [t for t in tasks if t['priority'].lower() == 'high' and t.get('status') != 'completed']
    for i, task in enumerate(high_tasks[:2]):  # Max 2 high priority in prime time
        time_table.append({
            'task': task['task'],
            'priority': 'high',
            'suggested_time': time_slots[i] if i < len(time_slots) else time_slots[0],
            'urgency': '🔥 Do First - Critical',
            'status': task.get('status', 'pending')
        })

    # Medium priority tasks - Afternoon and Evening
    medium_tasks = [t for t in tasks if t['priority'].lower() == 'medium' and t.get('status') != 'completed']
    for i, task in enumerate(medium_tasks[:2]):
        time_table.append({
            'task': task['task'],
            'priority': 'medium',
            'suggested_time': time_slots[i + 1] if i + 1 < len(time_slots) else time_slots[2],
            'urgency': '⚡ Do Next - Important',
            'status': task.get('status', 'pending')
        })

    # Low priority tasks - Evening and Night
    low_tasks = [t for t in tasks if t['priority'].lower() == 'low' and t.get('status') != 'completed']
    for i, task in enumerate(low_tasks[:2]):
        time_table.append({
            'task': task['task'],
            'priority': 'low',
            'suggested_time': time_slots[i + 2] if i + 2 < len(time_slots) else time_slots[3],
            'urgency': '💤 Do Last - Optional',
            'status': task.get('status', 'pending')
        })

    return time_table
import joblib
import pandas as pd
import numpy as np
from sklearn.metrics.pairwise import cosine_similarity
# ==========================================================
#                 /ml ROUTER (NO BLUEPRINT)
# ==========================================================

# ---- ML config paths (change if needed) ----
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
ML_MODEL_PATH = os.path.join(BASE_DIR, "ml_models", "BEST_category_model_LinearSVC.joblib")
ML_DATA_PATH  = os.path.join(BASE_DIR, "ml_models", "Task Catagories.csv.csv")

ML_TOP_K = 10      # recommendations
ML_TOP_CAT = 5     # category suggestions top-N

# ---- ML cached globals ----
_ml_MODEL = None
_ml_DF = None
_ml_VECTORIZER = None
_ml_TASK_MATRIX = None
_ml_CATEGORIES = []
_ml_SKILLS = []


def _ml_clean_df(df: pd.DataFrame) -> pd.DataFrame:
    df = df.copy()
    df["Task Description"] = df["Task Description"].fillna("").astype(str).str.strip()
    df["Category"] = df["Category"].fillna("").astype(str).str.strip().str.lower()
    df["Skill"] = df["Skill"].fillna("").astype(str).str.strip().str.lower()
    df = df[(df["Task Description"] != "") & (df["Category"] != "") & (df["Skill"] != "")].copy()
    return df


def ml_load_assets_once():
    """Load model+dataset only once."""
    global _ml_MODEL, _ml_DF, _ml_VECTORIZER, _ml_TASK_MATRIX, _ml_CATEGORIES, _ml_SKILLS

    if _ml_MODEL is not None:
        return

    if not os.path.exists(ML_MODEL_PATH):
        raise FileNotFoundError(f"ML model not found: {ML_MODEL_PATH}")
    if not os.path.exists(ML_DATA_PATH):
        raise FileNotFoundError(f"ML dataset not found: {ML_DATA_PATH}")

    _ml_MODEL = joblib.load(ML_MODEL_PATH)
    _ml_DF = pd.read_csv(ML_DATA_PATH)

    required_cols = {"Task Description", "Category", "Skill"}
    missing = required_cols - set(_ml_DF.columns)
    if missing:
        raise ValueError(f"Dataset missing columns: {missing}. Found: {_ml_DF.columns.tolist()}")

    _ml_DF = _ml_clean_df(_ml_DF)

    if not hasattr(_ml_MODEL, "named_steps") or "tfidf" not in _ml_MODEL.named_steps or "clf" not in _ml_MODEL.named_steps:
        raise ValueError("Saved model must be sklearn Pipeline with steps: 'tfidf' and 'clf'.")

    _ml_VECTORIZER = _ml_MODEL.named_steps["tfidf"]
    _ml_TASK_MATRIX = _ml_VECTORIZER.transform(_ml_DF["Task Description"].values)

    _ml_CATEGORIES = sorted(_ml_DF["Category"].unique().tolist())
    _ml_SKILLS = sorted(_ml_DF["Skill"].unique().tolist())


def ml_get_list():
    """Session list for ML selected tasks."""
    if "ml_task_list" not in session:
        session["ml_task_list"] = []
    return session["ml_task_list"]


def ml_category_suggestions(query_text: str, top_n: int = ML_TOP_CAT):
    """Top-N category suggestions with scores."""
    ml_load_assets_once()

    clf = _ml_MODEL.named_steps["clf"]
    Xv = _ml_VECTORIZER.transform([query_text])
    classes = getattr(clf, "classes_", None)
    if classes is None:
        return []

    # probability models (LogReg/NB)
    if hasattr(clf, "predict_proba"):
        probs = clf.predict_proba(Xv)[0]
        idx = np.argsort(-probs)[:top_n]
        return [{"category": str(classes[i]), "score": float(probs[i])} for i in idx]

    # margin models (LinearSVC)
    if hasattr(clf, "decision_function"):
        scores = clf.decision_function(Xv)
        scores = scores[0] if getattr(scores, "ndim", 1) > 1 else scores

        # pseudo probability for UI
        s = np.array(scores, dtype=float)
        s = s - np.max(s)
        exp = np.exp(s)
        denom = np.sum(exp) if np.sum(exp) != 0 else 1.0
        pseudo = exp / denom

        idx = np.argsort(-pseudo)[:top_n]
        return [{"category": str(classes[i]), "score": float(pseudo[i])} for i in idx]

    return []


def ml_recommend_tasks(query_text: str, category: str = None, skill: str = None, top_k: int = ML_TOP_K):
    """Return top_k tasks based on cosine similarity."""
    ml_load_assets_once()

    sub = _ml_DF
    if category:
        category = category.strip().lower()
        sub = sub[sub["Category"] == category]
    if skill:
        skill = skill.strip().lower()
        sub = sub[sub["Skill"] == skill]

    if len(sub) == 0:
        return []

    sub_idx = sub.index.to_numpy()
    sub_matrix = _ml_TASK_MATRIX[sub_idx]

    q_vec = _ml_VECTORIZER.transform([query_text])
    sims = cosine_similarity(q_vec, sub_matrix).ravel()

    top = np.argsort(-sims)[:top_k]
    out = sub.iloc[top].copy()
    out["similarity"] = sims[top]

    recs = []
    for _, row in out.iterrows():
        recs.append({
            "task": row["Task Description"],
            "category": row["Category"],
            "skill": row["Skill"],
            "similarity": float(row["similarity"])
        })
    return recs


# -----------------------------
# 1) /ml -> home.htm template
# -----------------------------
@app.route("/ml", methods=["GET"])
def ml_home():
    if "user" not in session:
        return redirect(url_for("login"))
        # ✅✅ PROFILE IMAGE FIX (Added inside same router)
    raw_image = session['user'].get('image', '') or ''
    clean_image = normalize_static_path(raw_image)
    if not clean_image:
        clean_image = 'img/default-avatar.png'  # put this in static/img/
    profile_image_url = url_for('static', filename=clean_image)
    ml_load_assets_once()

    # ✅ IMPORTANT: file name "home.htm"
    # If your template is home.html, change below accordingly
    return render_template(
        "home.html",
        user=session["user"],
        categories=_ml_CATEGORIES,
        skills=_ml_SKILLS,
        ml_list=ml_get_list(),
        profile_image_url=profile_image_url,  # ✅ Added
        top_k=ML_TOP_K,
        top_cat=ML_TOP_CAT
    )


# -----------------------------
# 2) POST /ml/predict
# -----------------------------
@app.route("/ml/predict", methods=["POST"])
def ml_predict():
    """
    JSON:
    {
      "questions": "line1\\nline2",
      "mode": "auto" | "manual",
      "category": "backend",
      "skill": "django"
    }
    """
    if "user" not in session:
        return jsonify({"ok": False, "error": "Please login first"}), 401

    ml_load_assets_once()
    data = request.get_json(silent=True) or {}

    questions_text = (data.get("questions") or "").strip()
    mode = (data.get("mode") or "auto").strip().lower()
    manual_category = (data.get("category") or "").strip().lower()
    skill = (data.get("skill") or "").strip().lower()

    if not questions_text:
        return jsonify({"ok": False, "error": "Questions are required."}), 400

    lines = [ln.strip() for ln in questions_text.splitlines() if ln.strip()]
    query_text = " ".join(lines)
    # ✅✅ PROFILE IMAGE FIX (Added inside same router)
    raw_image = session['user'].get('image', '') or ''
    clean_image = normalize_static_path(raw_image)
    if not clean_image:
        clean_image = 'img/default-avatar.png'  # put this in static/img/
    profile_image_url = url_for('static', filename=clean_image)
    suggestions = ml_category_suggestions(query_text, top_n=ML_TOP_CAT)

    predicted_category = None
    if mode == "auto":
        predicted_category = _ml_MODEL.predict([query_text])[0]
        used_category = predicted_category
    else:
        used_category = manual_category if manual_category else None

    used_skill = skill if skill else None

    recs = ml_recommend_tasks(query_text, category=used_category, skill=used_skill, top_k=ML_TOP_K)

    return jsonify({
        "ok": True,
        "predicted_category": predicted_category,
        "used_category": used_category,
        "used_skill": used_skill,
        "category_suggestions": suggestions,
        "recommendations": recs

    })


# -----------------------------
# 3) POST /ml/add_to_list
# -----------------------------
@app.route("/ml/add_to_list", methods=["POST"])
def ml_add_to_list():
    """
    JSON: {task, category, skill, similarity}
    """
    if "user" not in session:
        return jsonify({"ok": False, "error": "Please login first"}), 401

    data = request.get_json(silent=True) or {}
    task = (data.get("task") or "").strip()
    if not task:
        return jsonify({"ok": False, "error": "Task is required"}), 400

    lst = ml_get_list()
    if not any(x.get("task") == task for x in lst):
        lst.append({
            "task": task,
            "category": (data.get("category") or "").strip(),
            "skill": (data.get("skill") or "").strip(),
            "similarity": data.get("similarity", None)
        })
        session["ml_task_list"] = lst
        session.modified = True

    return jsonify({"ok": True, "ml_list": lst})


# -----------------------------
# 4) GET /ml/list
# -----------------------------
@app.route("/ml/list", methods=["GET"])
def ml_list_api():
    if "user" not in session:
        return jsonify({"ok": False, "error": "Please login first"}), 401
    return jsonify({"ok": True, "ml_list": ml_get_list()})


# -----------------------------
# 5) POST /ml/list/clear
# -----------------------------
@app.route("/ml/list/clear", methods=["POST"])
def ml_list_clear():
    if "user" not in session:
        return jsonify({"ok": False, "error": "Please login first"}), 401
    session["ml_task_list"] = []
    session.modified = True
    return jsonify({"ok": True, "ml_list": []})


# -----------------------------
# 6) OPTIONAL: prefill your existing /add_task form
# -----------------------------
@app.route("/ml/prefill_add_task", methods=["POST"])
def ml_prefill_add_task():
    """
    JSON: {task, category, skill}
    Saves prefill into session and returns redirect url for /add_task
    """
    if "user" not in session:
        return jsonify({"ok": False, "error": "Please login first"}), 401

    data = request.get_json(silent=True) or {}
    task = (data.get("task") or "").strip()
    if not task:
        return jsonify({"ok": False, "error": "Task is required"}), 400

    session["prefill_task_name"] = task
    session["prefill_task_details"] = f"Category: {data.get('category','')} | Skill: {data.get('skill','')}"
    session.modified = True

    return jsonify({"ok": True, "redirect": url_for("add_task")})

# Run the app
if __name__ == "__main__":
    app.run(debug=True)
